﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Make_payment
{
    public partial class Choose_Vehicle : Form
    {
        public Choose_Vehicle()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();

            const double qc = 0.0975;
            const double cd = 0.05;

            if (vanBtn.Checked)
            {
                double x = 400.00;
                double y = x * qc;
                double z = x * cd;
                form1.label16.Text = x.ToString() + "$";
                form1.label17.Text = y.ToString() + "$";
                form1.label18.Text = z.ToString() + "$";
                form1.label19.Text = (x + y + z).ToString() + "$";
            }
            else if (suvBtn.Checked)
            {
                double x = 300.00;
                double y = x * qc;
                double z = x * cd;
                form1.label16.Text = x.ToString() + "$";
                form1.label17.Text = y.ToString() + "$";
                form1.label18.Text = z.ToString() + "$";
                form1.label19.Text = (x + y + z).ToString() + "$";
            }
            else if (luxBtn.Checked)
            {
                double x = 500.00;
                double y = x * qc;
                double z = x * cd;
                form1.label16.Text = x.ToString() + "$";
                form1.label17.Text = y.ToString() + "$";
                form1.label18.Text = z.ToString() + "$";
                form1.label19.Text = (x + y + z).ToString() + "$";
            }
            form1.ShowDialog();
            this.Close();
        }
    }
}
