﻿CREATE TABLE [dbo].[PAYMENT] (
    [FirstName] 	    VARCHAR (50) NULL,
    [LastName]  	    VARCHAR (50) NULL,
    [PhoneNumber]  	    VARCHAR (50) NULL,
    [EmailAddress]  	VARCHAR (50) NULL,
    [CityProvince]  	VARCHAR (50) NULL,
    [CardHolderName]  	VARCHAR (50) NULL,
    [CardNumber]  	    INT (50) NULL,
    [ExpirationDate]  	INT (50) NULL,
    [CVC]  		        INT (50) NULL,
    CONSTRAINT [PK_Payment] PRIMARY KEY CLUSTERED ([FirstName] ASC)
);

