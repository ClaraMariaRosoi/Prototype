﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Make_payment
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Visa was selected.");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("MasterCard was selected.");
        }


        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\clara\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "insert into data (FirstName,LastName,PhoneNumber,EmailAddress,CityProvince,CardHolderName,CardNumber,ExpirationDate,CVC) values ('"+this.fNameTxtBox.Text+"' , '"+this.lNameTxtBox.Text+"' , '"+this.phoneNTxtBox.Text+"' , '"+this.emailTxtBox.Text+"' , '"+this.cityTxtBox.Text+"' , '"+this.cardNameTxtBox.Text+"' , '"+this.cardNbrTxtBox.Text+"' , '"+this.dateTxtBox.Text+"' , '"+this.CVCTxtBox.Text+")";

            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader dbr;

            if (fNameTxtBox.Text == "" || lNameTxtBox.Text == "" || phoneNTxtBox.Text == "" || emailTxtBox.Text == "" || 
                cityTxtBox.Text == "" || cardNameTxtBox.Text == "" || cardNbrTxtBox.Text == "" || dateTxtBox.Text == "" || CVCTxtBox.Text == "")
            {
                MessageBox.Show("Payment failed. Please try again.");
            }
            else
            {
                try
            {
                con.open();
                dbr = cmd.ExecuteReader();
                MessageBox.Show("Your payment is confirmed! A confirmation email will be sent shortly. " +
                "Thank you for choosing 5 - Star Automobile");
                while(dbr.read())
                {
                }
            }
            catch (Exception es)

            {
                MessageBox.Show(es.Message);
            }
                this.Close();
            }
                
        }
    }
}
