CREATE TABLE [dbo].[Appointmentdb] (
    [PickUpDate] VARCHAR (50) NOT NULL,
    [PickUpTime] VARCHAR (50) NOT NULL,
    [ReturnDate] VARCHAR (50) NOT NULL,
    [ReturnTime] VARCHAR (50) NOT NULL,
 
    CONSTRAINT [PK_Appointmentdb] PRIMARY KEY ([PickUpDate])
);