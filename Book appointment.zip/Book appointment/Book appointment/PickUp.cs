﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Book_appointment
{
    public partial class PickUp : Form
    {
        public PickUp()
        {
            InitializeComponent();
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            {
                dateTimePicker1.Text = string.Empty;
                dateTimePicker1.Checked = false;
                dateTimePicker1.CustomFormat = " ";
                dateTimePicker2.Text = string.Empty;
                dateTimePicker2.Checked = false;
                MessageBox.Show("Cleared the date and time.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Return returnForm = new Return();
            returnForm.ShowDialog();
        }

        private void applyBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\clara\Documents\Data.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "insert into data (DOB1,DOB2) values ('"+this.DateTimePicker1.Text+"' , '"+this.DateTimePicker2.Text+")";

            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader dbr;

            try
             {
                con.open();
                dbr = cmd.ExecuteReader();
                MessageBox.Show("Pick-up date selected for: " + dateTimePicker1.Text + " at " + dateTimePicker2.Text");
                while(dbr.read())
                {
                }
            }
            catch (Exception es)

            {
                MessageBox.Show(es.Message);
            }
        }
    }
}
