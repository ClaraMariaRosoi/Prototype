﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book_appointment
{
    public partial class Return : Form
    {
        public Return()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void continue2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(str);

            String str = "server=LAPTOP-CLARA;database=windowapp;UID=sa;password=123";
            String query = "insert into data (DOB1,DOB2) values ('"+this.DateTimePicker1.Text+"' , '"+this.DateTimePicker2.Text+")";

            SqlCommand cmd = new sqComamnd(query,con);
            SqlDataReader dbr;

            try
            {
                con.open();
                dbr = cmd.ExecuteReader();
                MessageBox.Show("Return date selected for: " + dateTimePicker1.Text + " at " + dateTimePicker2.Text);
                while(dbr.read())
                {
                }
            }
            catch (Exception es)

            {
                MessageBox.Show(es.Message);
            }
        }

        private void clear2Btn_Click(object sender, EventArgs e)
        {
            {
                dateTimePicker1.Text = string.Empty;
                dateTimePicker1.Checked = false;
                dateTimePicker1.CustomFormat = " ";
                dateTimePicker2.Text = string.Empty;
                dateTimePicker2.Checked = false;
                MessageBox.Show("Cleared the date and time.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Personal_information pi = new Personal_information();
            pi.ShowDialog();
        }
    }
}
